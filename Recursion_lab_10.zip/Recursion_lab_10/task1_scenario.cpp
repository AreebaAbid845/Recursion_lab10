#include <iostream>
using namespace std;



int main()
{
		int ticket_numbers[10] = {13579,26791,26792,33445,55555,62483,77777,79422,85647,93121};
		int winning_number;
		cout<<"enter this week's winning 5 digit number: ";
		cin>>winning_number;
		bool flag = false;
		for(int i =0; i<10; i++)
		{
			if(ticket_numbers[i]==winning_number)
			{
				cout<<"number is valid!";
				flag = true;
			}
		}
		if(!flag)
		{
		 cout<<"the number is invalid!"<<endl;
		}
}