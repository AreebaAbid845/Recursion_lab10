#include <iostream>
using namespace std;

int binarySearch(int l,int r, int arr[],int x)
{
	if(l<=r)
	{
		int mid = l + (r-l)/2;
		if(arr[mid]==x)
		{
			cout<<"found at index: "<<endl;
			return mid;
		}
		else if(arr[mid]>x)
		{
			return binarySearch(l,mid-1,arr,x);
		}
		else
		{
			return binarySearch(mid+1,r,arr,x);
		}
	}
}



int main()
{
	int arr[] = {1,2,3,4,5};
	cout<<binarySearch(0,4,arr,4);
}