#include <iostream>
using namespace std;

int linearSearch(int arr[], int x)
{
	int n = sizeof(arr);
	for(int i=0; i<n; i++)
	{
		if(arr[i]==x)
		{
			return i;
		}
	}
	return -1;
}

int main()
{
	int arr[] = {23,54,67,245,98};
	int x = 54;
	
	int result = linearSearch(arr,x);
	if(result==-1)
	{
		cout<<"element not found!"<<endl;
	}
	else
	{
		cout<<"element found at index: "<<result<<endl;
	}
	
}