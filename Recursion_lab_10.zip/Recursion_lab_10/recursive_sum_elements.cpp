#include <iostream>
using namespace std;


int sum_elements(int arr[],int i,int sum,int size)
{
	if(i==size)
	{
		return sum;
	}
	else
	{
	
	sum = arr[i] + sum;
	i++;
	return sum_elements(arr,i,sum,size);
}
}
int main()
{
	int arr1[5] = {1,2,3,4,5};
	cout<<sum_elements(arr1,0,0,5);
}