#include <iostream>
using namespace std;

int sum(int arr[], int isum)
{
	int i=0;
	if(i<=sizeof(arr))
	{
		return isum;
	}
	isum = 0;

	
	isum  = arr[i] + isum;
	i++;
	return sum(arr,isum);
}

int main()
{
	int arr[] = {1,2,3,4,5};
	cout<<sum(arr,0);
}